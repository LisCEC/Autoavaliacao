import { GoogleGenAI, Type } from "@google/genai";
import { FormData, ReportData } from "../types";
import { SECTIONS } from "../constants";

export const generateAIReport = async (formData: FormData): Promise<ReportData> => {
  // Relatório de contingência (caso a IA falhe ou esteja offline)
  const fallbackReport: ReportData = {
    summary: "O sistema gerou este relatório preliminar pois não foi possível conectar à Inteligência Artificial no momento. Os dados abaixo refletem suas respostas diretas e devem ser analisados presencialmente com a coordenação.",
    strengths: ["Preenchimento completo do formulário", "Pontualidade na entrega", "Autoavaliação realizada"],
    improvements: ["A análise detalhada de IA está indisponível no momento", "Discutir pontos específicos presencialmente"],
    developmentPlan: "Recomenda-se agendar uma reunião com a coordenação para debater os pontos levantados no formulário."
  };

  try {
    if (!process.env.API_KEY) {
      console.warn("API Key missing. Using fallback report.");
      return fallbackReport;
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Construct user data summary
    let promptData = `Nome: ${formData.userInfo.name}\n\n`;

    // Competencies
    promptData += "--- AVALIAÇÃO DE COMPETÊNCIAS (Escala 1-10) ---\n";
    SECTIONS.filter(s => s.type === 'COMPETENCY').forEach(section => {
      const data = formData.competencies[section.id];
      promptData += `\nSetor: ${section.title}\n`;
      promptData += `Nota: ${data?.rating || 0}/10\n`;
      promptData += `Reflexão do Colaborador: "${data?.reflection || 'Não preenchido'}"\n`;
    });

    // Open Text
    promptData += "\n--- DESAFIOS E CONQUISTAS ---\n";
    SECTIONS.filter(s => s.type === 'OPEN_TEXT').forEach(section => {
      section.fields?.forEach(field => {
        promptData += `${field.label}: ${formData.textAnswers[field.id] || '-'}\n`;
      });
    });

    // Development
    promptData += "\n--- DESENVOLVIMENTO ---\n";
    SECTIONS.filter(s => s.type === 'DEVELOPMENT').forEach(section => {
      section.fields?.forEach(field => {
        promptData += `${field.label}: ${formData.textAnswers[field.id] || '-'}\n`;
      });
    });

    const prompt = `
      Atue como um Especialista em RH Sênior e Desenvolvimento Humano do CEC - Centro de Educação e Cultura.
      Analise a autoavaliação detalhada de um Auxiliar Administrativo abaixo e gere um relatório de feedback executivo.
      
      DADOS DO COLABORADOR:
      ${promptData}

      OBJETIVO:
      Gerar um feedback construtivo, acolhedor e estratégico, focado no crescimento profissional.

      REGRAS DE OUTPUT (JSON):
      1. 'summary': Um resumo executivo (aprox. 80 palavras) do perfil atual do colaborador baseado nas notas e reflexões.
      2. 'strengths': 3 a 4 pontos fortes principais identificados nas narrativas e notas altas.
      3. 'improvements': 3 a 4 pontos de atenção ou oportunidades de melhoria identificadas nas notas baixas ou desafios relatados.
      4. 'developmentPlan': Uma sugestão curta de plano de desenvolvimento (um parágrafo) baseada no que ele deseja estudar e nas necessidades identificadas.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            improvements: { type: Type.ARRAY, items: { type: Type.STRING } },
            developmentPlan: { type: Type.STRING }
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as ReportData;
    }
    
    return fallbackReport;
  } catch (error) {
    console.error("AI Generation Error", error);
    // Retorna o fallback em caso de qualquer erro, garantindo que o usuário veja a próxima tela
    return fallbackReport;
  }
};